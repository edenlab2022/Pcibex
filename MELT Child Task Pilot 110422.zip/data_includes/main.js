PennController.ResetPrefix(null)

DebugOff()

// ASSIGN VARS
//set up and trials
var prep = seq("loadKeys", "Intro")
var musicTask = seq("InstructionsEmoMusic", "StartMusic", "PracticeEmoMusic", "BreakEmoMusic", randomize("ExperimentalEmoMusic"), "TaskEnd") 
var finalArr = seq(prep, musicTask)

// get ordered color condition group - needed?
var color_order = Math.floor(Math.random() * 6)
var groups = createColorGroup(color_order)
var leftColor = groups[0] + ""
var centerColor = groups[1] + ""
var rightColor = groups[2] + ""
var color_order_label = groups[3] + ""

SetCounter("counter", "inc", 1);

//order of tasks
Sequence("counter", finalArr, "Finish")

function createColorGroup(int) {
    var bugba = ["blue", "green", "black", "bugba"];
    var gbuba = ["green", "blue", "black", "gbuba"];
    var bagbu = ["black", "green", "blue", "bagbu"];
    var gbabu = ["green", "black", "blue", "gbabu"];
    var babug = ["black", "blue", "green", "babug"];
    var bubag = ["blue", "black", "green", "bubag"];
    
    var groups = [bugba, gbuba, bagbu, gbabu, babug, bubag];
    
    return groups[int]; 
}

// color order var generation
newTrial("color_order",
    newVar("colorOrder")
        .global()
        .set(color_order_label)
).log("id", getVar("subjID"))
.log("color_group", color_order_label)

// STUDY INTRO 
newTrial("Intro", 
    newText("intro", "<p><strong>Welcome to the Music Game!</strong>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("test", color_order_label + "")
        .center()
        .print()
    ,*/
    newText("description", "Now we will play a game with music and I want you to tell me which feelings go with the music.</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("id_prompt", "Enter Participant ID:")
        .center()
        .css("font-size", "1.5em")
        .print()
    ,
    newTextInput("idnum")
        .center()
        .log("final")
        .lines(1)
        .print()
    ,
    newText("spacer", "<p></p>").center().print()
    ,
    newButton("submit", "SUBMIT")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait(
            getButton("submit").test.clicked()
            .and(getTextInput("idnum").testNot.text("")
                    .failure(
                        newText("error", "<p>Please enter the participant's ID.")
                            .center()
                            .css("font-size", "1.0em")
                            .color("red")
                            .print() 
                        )
                    .success(
                        newVar("subjID")
                            .global()
                            .set(getTextInput("idnum"))
                        )
                )
            )
    ,
    clear()
    ).log("id", getVar("subjID"))

//EMO ID Trials
Template(
    GetTable("emoMusicGroupedIntroV2.csv")
    ,
// Instructions and Emotion ID Trials
row => newTrial("InstructionsEmoMusic",
    /*newText("one", "<p>Now we will play a game with music and I want you to tell me <strong>which feelings go with the music.</strong></p>")
        .css("font-size", "2.0em")
        .css("text-align","center")
        .center()
        .print()
    ,*/
    newText("two", "<p>First, let's check how these people are feeling.</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    newText("spacer", "<p></p>")
        .settings.center()
        //.print()
    ,
    defaultImage.size(150, 180)
    ,
    newImage(getImageEmotion(row.leftImage)+"", leftColor + row.leftImage +"")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newImage("calmImage", centerColor + "calmnolabel.jpg")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newImage(getImageEmotion(row.rightImage)+"", rightColor + row.rightImage +"")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newCanvas("labels", 600, 200)
        .add("center at 18%", "middle at 50%", getImage(getImageEmotion(row.leftImage)+""))
        .add("center at 50%", "middle at 50%", getImage("calmImage"))
        .add("center at 82%", "middle at 50%", getImage(getImageEmotion(row.rightImage)+""))
        .color("yellow")
        .cssContainer("border", "solid 2px black")
        .settings.center()
        .print()
    ,
    getText("spacer")
        .center()
        .print()
    ,
    newButton("continue", "CONTINUE")
        .css("font-size", "1.5em")
        .center()
        //.print()
        //.wait()
    ,
    getButton("continue")
        .settings.center()
        .print()
        .wait()
    ,
    getButton("continue").hidden().remove()
    ,
    getText
    ,newText("sad_point", "Who looks like they are feeling <strong>sad</strong>?</p> You can tell me the <strong>color</strong> of the face, or <strong>point</strong> to the face and your parent can tell me who you pointed to. </p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    /*newText("warning", "<p>Wrong. Please try again.</p>")
        .css("font-size", "1.5em")
        .center()
        .color("red")
        .hidden()
    , 
    newText("correct", "<p>That's right! Great job!</p>")
        .css("font-size", "1.5em")
        .center()
        .color("green")
        .hidden()
    ,
    newSelector("id_sad")
        .add(
            getImage(getImageEmotion(row.leftImage)+"")
            ,
            getImage("calmImage")
            ,
            getImage(getImageEmotion(row.rightImage)+"")
            )
        //.shuffle()
        .frame("dashed 0px white")
    ,
    getSelector("id_sad")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("id_sad")
                .test.selected(getImage("sadImage"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").hidden().remove()
    ,*/
    getButton("continue")
        .visible()
        .print()
        .wait()
        .hidden()
        .remove()
    ,
    getText("sad_point").remove()
    ,
    /*getText("correct").hidden().remove()
    ,
    getSelector("id_sad")
        .disableClicks()
        .hidden()
        .remove()
    ,*/
    
    newText("scared_point", "Who looks like they are feeling <strong>scared</strong>?</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    /*newSelector("id_scared")
        .add(
            getImage("sadImage")
            ,
            getImage("calmImage")
            ,
            getImage("scaredImage")
            )
        //.shuffle()
        .frame("dashed 0px white")
    ,
    getSelector("id_scared")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("id_scared")
                .test.selected(getImage("scaredImage"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").hidden().remove()
    ,*/
    getButton("continue")
        .visible()
        .print()
        .wait()
        .hidden()
        .remove()
    ,
    getText("scared_point").remove()
    ,
    /*getSelector("id_scared")
        .disableClicks()
        .hidden()
        .remove()
    ,*/
    newText("calm_point", "Who looks like they are feeling <strong>calm or relaxed</strong>?</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    /*newSelector("id_calm")
        .add(
            getImage("sadImage")
            ,
            getImage("calmImage")
            ,
            getImage("scaredImage")
            )
        //.shuffle()
        .frame("dashed 0px white")
    ,
    getSelector("id_calm")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("id_calm")
                .test.selected(getImage("calmImage"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").hidden().remove()
    ,
    getButton("continue")
        .visible()
        .print()
        .wait()
        .hidden()
        .remove()
    ,
    getText("calm_point").remove()
    ,
    getText("correct").hidden().remove()
    ,
    getSelector("id_calm")
        .disableClicks()
        .hidden()
        .remove()
    ,
    newText("praise", "<p>Great job! Let's say them together one more time.</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,*/
    newButton("next", "NEXT")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    )
)

// MusicAudioTest - not in use    
newTrial("MusicAudioTest",
    newText("instructions", "<p>Please make sure your volume is on. Listen to the audio and type the word you hear into the box below. Click the CONTINUE button to verify your answer and proceed.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newAudio("book", "Book.ogg")
        .settings.center()
        .print()
    ,
    newText("spacer", "<p> </p>")
        .settings.center()
        .print()
    ,
    getText("spacer")
        .settings.center()
        .print()
    ,
    newTextInput("keyword")
        .settings.center()
        .print()
    ,
    getText("spacer")
        .settings.center()
        .print()
    ,
    newText("warning", "Please try again. Make sure the word is spelled correctly and there are no extra spaces in the box.") 
        .center()
        .color("red")
        .print()
        .hidden()
    ,
    getText("spacer")
        .settings.center()
        .print()
    ,
    newText("verifyText", "Click VERIFY to check your answer.") 
        .center()
        .print()
    ,
    newButton("verify", "VERIFY")
        .print()
        .center()
        .callback(
            getTextInput("keyword").test.text("book").or(getTextInput("keyword").test.text("BOOK")).or(getTextInput("keyword").test.text("Book"))
            .success(getText("warning").settings.hidden())
            .failure(getText("warning").settings.visible())
        )
        
        .wait(getTextInput("keyword").test.text("book").or(getTextInput("keyword").test.text("BOOK")).or(getTextInput("keyword").test.text("Book"))) 
    )
 
//Start Screen    
newTrial("StartMusic", 
    newText("great", "Great job!")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    
    newText("1", "<p>Now, you will hear some music and then you can tell me the <strong>color</strong> of the face, or <strong>point</strong> to the face with <strong>feelings that match the music</strong>. Parent, if they point, please tell us the color of the face once the music finishes.</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    newText("2", "Let's practice!<p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newButton("continue", "CONTINUE")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
)

function getImageEmotion(imageName) {
    var newString = "" + imageName;
     
    if (newString === "fearnolabel.jpg") {
        return "scaredImage";
    }
    
    return "sadImage";
} 


            //START PRACTICE TRIALS
Template(
    GetTable("emoMusicGroupedPracticeV2.csv")
    ,
    row => newTrial("PracticeEmoMusic",
        newAudio(row.audiofile)
            .center()
            .print()
            //.play()
            .wait() 
        ,clear()
        ,
        newText("Q", "<p>Whose face matches the music?</p>")
            .center()
            .css("font-size", "1.5em")
            .print()
        ,
        newSelector("eugenies")
            .once()
            .frame("dashed 0px white")
        ,
        defaultImage.size(150, 180)
        ,
        newImage(getImageEmotion(row.leftImage)+"", leftColor + row.leftImage +"")
            .selector("eugenies")
            .cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            //.print()
            .size(150, 180)
        ,
        newImage("calmImage", centerColor + "calmnolabel.jpg")
            .selector("eugenies")
            .cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            //.print()
            .size(150, 180)
        ,
        newImage(getImageEmotion(row.rightImage)+"", rightColor + row.rightImage +"")
            .selector("eugenies")
            .cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            //.print()
            .size(150, 180)
        ,
        newCanvas("eugenieslabels", 600, 200)
            .center()
            .add("center at 18%", "middle at 50%", getImage(getImageEmotion(row.leftImage)+""))
            .add("center at 50%", "middle at 50%", getImage("calmImage"))
            .add("center at 82%", "middle at 50%", getImage(getImageEmotion(row.rightImage)+""))
            .color("yellow")
            .cssContainer("border", "solid 2px black")
            .settings.center()
            .print()
        ,
        newKey("idk", "Escape", "Enter")
            .selector("eugenies")
            .callback(
                getSelector("eugenies").select(getKey("idk"))
                )
        ,
        getSelector("eugenies")
            .wait()
            .log("last")
        ,
        newText("correct", "Great job!<p>")
            .css("font-size", "1.5em")
            .center()
            .color("green")
            .print()
        ,
        /*newText("Press space to continue.")
            .css("font-size", "1.5em")
            .center()
            .print()
        ,
        newKey(" ")
            .wait()
        ,
        clear()*/
        newButton("next", "NEXT").center().print()
    )
    .log("id", getVar("subjID"))
    .log("audiofile", row.audiofile)
    .log("correctanswer", row.correctanswer)
    .log("ExpGroup", row.Group)
    .log("color_group", color_order_label)
)

// pre-experimental trial screen  
newTrial("BreakEmoMusic",
    newText("1", "<p>Great job! Now we will start the real game. Are you ready?</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    /*newText("2", "<p>Press the START button when ready.</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,*/
    newButton("start", "START")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    )

// experimental trials
Template(
    GetTable("emoMusicExpGroupedV2.csv")
    ,
    row => newTrial("ExperimentalEmoMusic",
        newVar("trialOrder", 0)
            .global()
            .set( v=>v+1 )
        ,
        newAudio(row.audiofile)
            .center()
            .print()
            //.play()
            .wait()
        ,clear()
        ,
        newText("Q", "<p>Whose face matches the music?</p>")
            .center()
            .css("font-size", "1.5em")
            .print()
        ,
        newSelector("eugenies")
            .once()
            .frame("dashed 0px white")
        ,
        newImage(getImageEmotion(row.leftImage)+"", leftColor + row.leftImage +"")
            .selector("eugenies")
        ,
        newImage("calmImage", centerColor + "calmnolabel.jpg")
            .selector("eugenies")
        ,
        newImage(getImageEmotion(row.rightImage)+"", rightColor + row.rightImage +"")
            .selector("eugenies")
        ,
        defaultImage.size(150, 180)
        ,
        newCanvas("eugenieslabels", 600, 200)
            .center()
            .add("center at 18%", "middle at 50%", getImage(getImageEmotion(row.leftImage)+""))
            .add("center at 50%", "middle at 50%", getImage("calmImage"))
            .add("center at 82%", "middle at 50%", getImage(getImageEmotion(row.rightImage)+""))
            .print()
        ,
        newKey("idk", "Escape", "Enter")
            .selector("eugenies")
            .callback(
                getSelector("eugenies").select(getKey("idk"))
                )
        ,
        getSelector("eugenies")
            .wait()
            .log("last")
        /*,
        newText("<p>Press space to continue.</p>")
            .css("font-size", "1.5em")
            .center()
            .print()
        ,
        newKey(" ")
            .wait()
        */
    )
                            //SAVING TRIAL INFORMATION
    .log("id", getVar("subjID"))
    .log("audiofile", row.audiofile)
    .log("correctanswer", row.correctanswer)
    .log("ExpGroup", row.Group)
    .log("trialOrder", getVar("trialOrder"))
    .log("color_group", color_order_label)
) 

// end of task generic trial
newTrial("TaskEnd",
    newText("conclusion", "<p>All done, great job!</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newButton("continue", "CONTINUE")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
)

//Finish page
newTrial("Finish",
    SendResults()
    ,
    newText("1", "<p>Nice job! Those are all the games we will play today. Thank you very much for doing this activity with us!") 
        .center()
        .css("text-align", "center")
        .css("font-size", "2.0em")
        .print()
    ,
    /*newText("code", "Your completion code is:")
        .center()
        .css("font-size", "1.5em")
        .print()
    ,
    newText("displayid", idnum.toString(10))
        .center()
        .css("font-size", "1.5em")
        .print()
    ,*/
    newText("blank", "<p> </p>")
        .print()
    ,
    newButton("finish", "FINISH")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    newButton("End").wait()
)