PennController.ResetPrefix(null)

DebugOff()

// ASSIGN VARS
//set up and trials

var prep = seq("loadKeys", "Intro", "color_order", "AudioTest") //READY
var resonTask = seq("loadKeys", "ResonInstructions", "ResonPractice", "ResonStart", sepHalfway("ResonCheckpoint", randomize("ResonExperiment")), "TaskEnd")
var recogTask = seq("loadKeys", "RecogInstructions", "EmoRecognition", "RecogPractice", "RecogStart", sepHalfway("RecogCheckpoint", randomize("RecogExperiment")), "TaskEnd")
//var resonTask = seq("loadKeys", "ResonInstructions", "ResonPractice", "ResonStart", randomize("ResonExperiment"), "TaskEnd")
//var recogTask = seq("loadKeys", "RecogInstructions", "RecogPractice", "RecogStart", randomize("RecogExperiment"), "TaskEnd")

//randomize trial order 
var roughArr = randomizeTasks(resonTask, recogTask)
var finalArr = seq(prep, roughArr[0], roughArr[1])

// get ordered color condition group
var color_order = Math.floor(Math.random() * 6)
//var group = createTestGroup(color_order)
var groups = createTestGroup()
var group = groups[color_order]
var cond_label = group[3] + ""
var labels = [group[0] + "", group[1] + "", group[2] + ""]
// "labels" is in order: [mean, neutral, nice]

SetCounter("counter", "inc", 1);

//order of tasks
Sequence("counter", finalArr, "Finish")


//fcn: randomize order of reson/recog tasks 
function randomizeTasks(one, two) {
    var temp = [one, two]; 
    var allArr = [two, one];
    
    //random num, either 0 or 1
    var number = Math.floor(Math.random() * 2);
    
    if (number == 0) {
        return temp;
    }
    else {
        return allArr;
    }

    //return allArr;
} 

/*function createTestGroup(int) {
    var gone = ["mean_blue.png", "neutral_green.png", "nice_black.png"];
    var gtwo = ["mean_green.png", "neutral_blue.png", "nice_black.png"];
    var gthree = ["mean_black.png", "neutral_green.png", "nice_blue.png"];
    var gfour = ["mean_green.png", "neutral_black.png", "nice_blue.png"];
    var gfive = ["mean_black.png", "neutral_blue.png", "nice_green.png"];
    var gsix = ["mean_blue.png", "neutral_black.png", "nice_green.png"];
    
    var MBeNuGNiBk = ["mean_blue.png", "neutral_green.png", "nice_black.png"];
    var MGNuBeNiBk = ["mean_green.png", "neutral_blue.png", "nice_black.png"];
    var MBkNuGNiBe = ["mean_black.png", "neutral_green.png", "nice_blue.png"];
    var MGNuBkNiBe = ["mean_green.png", "neutral_black.png", "nice_blue.png"];
    var MBkNuBeNiG = ["mean_black.png", "neutral_blue.png", "nice_green.png"];
    var MBeNuBkNiG = ["mean_blue.png", "neutral_black.png", "nice_green.png"];
    
    //var groups = [gone, gtwo, gthree, gfour, gfive, gsix];
    var groups = [MBeNuGNiBk, MGNuBeNiBk, MBkNuGNiBe, MGNuBkNiBe, MBkNuBeNiG, MBeNuBkNiG];
    var glabels = ["MBeNuGNiBk", "MGNuBeNiBk", "MBkNuGNiBe", "MGNuBkNiBe", "MBkNuBeNiG", "MBeNuBkNiG"];
    
    getVar("glabels")
        .global()
        //.set(groups_labels[int])
        //.log("cond", getVar("groups_labels"))
    
    return groups[int]; 
}*/

function createTestGroup() {
    var MBeNuGNiBk = ["mean_blue.png", "neutral_green.png", "nice_black.png", "MBeNuGNiBk"];
    var MGNuBeNiBk = ["mean_green.png", "neutral_blue.png", "nice_black.png", "MGNuBeNiBk"];
    var MBkNuGNiBe = ["mean_black.png", "neutral_green.png", "nice_blue.png", "MBkNuGNiBe"];
    var MGNuBkNiBe = ["mean_green.png", "neutral_black.png", "nice_blue.png", "MGNuBkNiBe"];
    var MBkNuBeNiG = ["mean_black.png", "neutral_blue.png", "nice_green.png", "MBkNuBeNiG"];
    var MBeNuBkNiG = ["mean_blue.png", "neutral_black.png", "nice_green.png", "MBeNuBkNiG"];
    
    //var groups = [gone, gtwo, gthree, gfour, gfive, gsix];
    var groups = [MBeNuGNiBk, MGNuBeNiBk, MBkNuGNiBe, MGNuBkNiBe, MBkNuBeNiG, MBeNuBkNiG];
    
    return groups; 
}

// functions to splice in checkpoint trials at regular intervals
function SepHalfway(sep, main) {
    this.args = [sep,main];

    this.run = function(arrays) {
        assert(arrays.length == 2, "Wrong number of arguments (or bad argument) to SepHalfway");
        let sep = arrays[0];
        let main = arrays[1];
        var half = Math.floor(main.length / 2);
        var full = main.length;
        var temp = main;
        temp.splice(half, 0, sep.pop());
        return temp;
    }
}

// helper
function sepHalfway(sep, main) {
    return new SepHalfway(sep, main);
}


//condition group var generation
newTrial("color_order",
    newVar("order")
        .global()
        .set(color_order)
    ,
    newVar("group_l")
        .global()
        .set(cond_label)
).log("id", getVar("subjID"))
.log("group", getVar("group_l"))

// STUDY INTRO 
newTrial("Intro", 
    newText("intro", "<p><strong>Welcome to the Laughter Game!</strong></p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("description", "In this activity, you will hear people laughing and we will ask you some questions about what you heard.</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newButton("ok", "OK")
        .center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    ,*/
    newText("id_prompt", "Enter Participant ID:")
        .center()
        .css("font-size", "1.5em")
        .print()
    ,
    newTextInput("idnum")
        .center()
        .log("final")
        .lines(1)
        .print()
    ,
    newText("<p></p>")
        .center().print()
    ,
    newButton("submit", "SUBMIT")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait(
            getButton("submit").test.clicked()
            .and(getTextInput("idnum").testNot.text("")
                    .failure(
                        newText("error", "<p>Please enter the participant's ID.</p>")
                            .center()
                            .css("font-size", "1.0em")
                            .color("red")
                            .print() 
                        )
                    .success(
                        newVar("subjID")
                            .global()
                            .set(getTextInput("idnum"))
                        )
                )
            )
    ,
    clear()
    ).log("id", getVar("subjID"))


//audio check 
newTrial("AudioTest",
    newText("test_intro", "<p>Before we start the activity, let's make sure you can hear the sound okay.</p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("volume", "Please make sure your volume is on and turned up.</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("instructions_audiotest", "<p>Please make sure your volume is on. We will play a word. Please listen to the audio and say back the word you hear.</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newButton("ok", "OK!")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,*/
    /*newText("instructions_audiotest1", "<p>Here's the first word. Please listen to the audio and say back the word you hear.</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    /*newButton("ok", "OK")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,*/
    newAudio("apple", "Apple.ogg")
        .settings.center()
        .print()
        //.play()
    ,
    newText("spacer", "<p> </p>").center()
    //,getText("spacer").center().print()
    ,
    newText("instructions_audiotest", "<p>What word did you hear?</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newButton("next", "Next Question!")
        .css("font-size", "1.5em")
        .center()
        .hidden()
    ,
    newButton("cont", "Continue")
        .css("font-size", "1.5em")
        .center()
        .hidden()
    ,
    /*newText("warning", "<p>Wrong. Please try again.</p>")
        .css("font-size", "1.5em")
        .center()
        .color("red")
        .hidden()
    , 
    newText("correct", "<p>That's right! Great job!</p>")
        .css("font-size", "1.5em")
        .center()
        .color("green")
        .hidden()
    ,
    defaultImage.size(150, 180)
    ,
    newImage("apple_image", "apple.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newImage("man_image", "man2_black.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newImage("woman_image", "woman2_black.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newCanvas("audio_canvas", 600, 200)
        .color("yellow")
        .cssContainer("border", "solid 2px black")
        .settings.center()
        .add("center at 18%", "middle at 50%", getImage("apple_image"))
        .add("center at 50%", "middle at 50%", getImage("man_image"))
        .add("center at 82%", "middle at 50%", getImage("woman_image"))
        .print()
    ,
    newSelector("audiotest_q")
        .add(
            getImage("apple_image")
            ,
            getImage("man_image")
            ,
            getImage("woman_image")
            )
        .shuffle()
    //,getText("spacer").center().print()
    ,
    getSelector("audiotest_q")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("audiotest_q")
                .test.selected(getImage("apple_image"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").hidden().remove()
    ,
    getImage("man_image").remove()
    ,
    getImage("woman_image").remove()
    //,getText("spacer").center().print()
    ,
    /*getButton("next")
        .visible()
        .print()
        .wait()
        .hidden()
    ,*/
    getButton("cont")
        .visible()
        .print()
        .wait()
        .hidden()
    //,getText("correct").hidden().remove()
    ,
    clear()
    /*,
    newText("instructions_audiotest2", "<p>Great job! Let's try another. Please listen to the audio and say back the word you hear.</p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newAudio("book", "Book.ogg")
        .settings.center()
        .print()
        //.play()
    ,
    getText("spacer").center().print()
    ,
    newImage("book_image", "book_image.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newCanvas("audio_canvas2", 600, 200)
        .color("yellow")
        .cssContainer("border", "solid 2px black")
        .settings.center()
        .add("center at 18%", "middle at 50%", getImage("book_image"))
        .add("center at 50%", "middle at 50%", getImage("man_image"))
        .add("center at 82%", "middle at 50%", getImage("woman_image"))
        .print()
        
    ,
    newSelector("audiotest_q2")
        .add(
            getImage("book_image")
            ,
            getImage("man_image")
            ,
            getImage("woman_image")
            )
        .shuffle()
    //,getText("spacer").center().print()
    ,
    getSelector("audiotest_q2")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("audiotest_q2")
                .test.selected(getImage("book_image"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").hidden().remove()
    ,
    getImage("man_image").remove()
    ,
    getImage("woman_image").remove()
    //,getText("spacer").center().print()
    ,
    getButton("next")
        .visible()
        .print()
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()*/
)

// Emotion Recognition Check
newTrial("EmoRecognition",
    newText("one", "<p>First, let's check how these people are feeling.</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newText("spacer", "<p></p>")
        .center()
    ,
    defaultImage.size(150, 180)
    ,
    newImage("mean_image", labels[0])
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newImage("neutral_image", labels[1])
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newImage("nice_image", labels[2])
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newCanvas("recog_canvas", 600, 200)
        .add("center at 18%", "middle at 50%",  getImage("mean_image"))
        .add("center at 50%", "middle at 50%",  getImage("neutral_image"))
        .add("center at 82%", "middle at 50%",  getImage("nice_image"))
        .color("yellow")
        .cssContainer("border", "solid 2px black")
        .settings.center()
        .print()
    ,
    getText("spacer")
        .center()
        .print()
    ,
    newButton("continue", "CONTINUE")
        .settings.center()
        .css("font-size", "1.5em")
        //.print()
        //.wait()
    ,
    getButton("continue")
        .settings.center()
        .print()
        .wait()
    ,
    getButton("continue").hidden().remove()
    ,
    /*newText("nice_point", "Who looks like they are laughing with a <strong>nice or friendly</strong> face?</p> You can tell me the <strong>color</strong> of the face, or <strong>point</strong> to the face and your parent can tell me who you pointed to.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align","center")
        .print()
    ,*/
    newText("mean_point", "Who looks like they are <strong>laughing with a mean or unfriendly face?</strong></p> You can tell me the <strong>color</strong> of the face, or <strong>point</strong> to the face and your parent can tell me who you pointed to.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align","center")
        .print()
    ,
    getButton("continue")
        .visible()
        .print()
        .wait()
        .hidden()
        .remove()
    //,getText("nice_point").remove()
    ,
    getText("mean_point").remove()
    ,
    /*newText("mean_point", "Who looks like they are laughing with a <strong>mean or unfriendly</strong> face?</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align","center")
        .print()
    ,*/
    newText("nice_point", "Who looks like they are <strong>laughing with a nice or friendly face?</strong></p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align","center")
        .print()
    ,
    getButton("continue")
        .visible()
        .print()
        .wait()
        .hidden()
        .remove()
    //,getText("mean_point").remove()
    ,
    getText("nice_point").remove()
    ,
    newText("calm_point", "Who looks like they are <strong>not laughing</strong> and have a <strong>calm face?</strong></p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align","center")
        .print()
    ,
    newButton("next", "NEXT")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    )

//InstructionsLaughter 
//--> ResonInstructions/RecogInstructions
newTrial("ResonInstructions",
    newText("<p>You will hear a person laughing and I want you to tell me <strong>if you want to play with that person.</strong></p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("<p>Now we're going to hear people laughing. Afterwards, we'll ask you <strong>if you would like to play with the person who was laughing.</strong></p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("Please answer either yes or no. If you're not sure, you can also say 'I don't know' or 'I'm not sure.'")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    newText("You can say yes, no, or 'I don't know' or I'm not sure.'")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("spacer", "<p> </p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("<p>Please make sure you have your volume turned up! <strong>Before you begin, we will do a practice trial together.</strong></p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    newText("<p><strong>Let's practice.</strong></p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newButton("continue", "CONTINUE")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
        .wait()
)

newTrial("RecogInstructions",
    /*newText("<p>Now we're going to hear people laughing. Afterwards, we'll ask you <strong>who you think was laughing.</strong></p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("Please <strong>point</strong> to the person who you think was laughing. Parent, once they have pointed, please tell us the <strong>color</strong> of the person they chose. If they're not sure, you can also say 'I don't know' or 'I'm not sure.'")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    newText("<p>Now you will hear the sound of someone laughing, and I want you to tell me which face <strong>looks like it goes with the person laughing.</strong></p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("Please <strong>point</strong> to the person who you think was laughing. Parent, once they have pointed, please tell us the <strong>color</strong> of the person they chose. If they're not sure, you can also say 'I don't know' or 'I'm not sure.'")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("spacer", "<p> </p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("<p>Please make sure you have your volume turned up! <strong>Before you begin, we will do a practice trial together.</strong></p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    newButton("continue", "CONTINUE")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
        .wait()
)


// two practice trials
newTrial("ResonPractice",
    /*newTimer("1", 400)
        .start()
        .wait()
    ,
    newText("practice", "<p>This is a practice trial. The audio will play on its own. <strong>You will only be able to listen to the laugh once.</strong></p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newButton("cont", "LET'S PRACTICE!")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,*/
    newTimer("2", 400)
        .start()
        .wait()
    ,
    newText("question", "<p>Do you want to play with this person?</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newAudio("one", "PRACTICE_1_A.ogg")
        .settings.center()
        .print()
        .once()
        //.play()
        .wait()
        .remove()
    ,
    /*getAudio("one").test.hasPlayed() 
        .wait()
        //.remove()
    ,*/
    newText("<p></p>")
        .center()
        .print()
    ,
    defaultImage.size(180, 180)
    ,
    newImage("yes", "yes_check.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newImage("no", "no_cross.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    /*newImage("idk", "dontknow_question.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        .size("5vw", "5vh")
        .print()
    ,*/
    newCanvas("reson_prac_canvas", 600, 200)
        .add("center at 30%", "middle at 50%",  getImage("yes"))
        .add("center at 70%", "middle at 50%",  getImage("no"))
        //.add("right at 95%", "bottom at 95%",  getImage("idk"))
        .color("yellow")
        .cssContainer("border", "solid 2px black")
        .center()
        .print()
    ,
    newSelector("reson_prac_q")
        .add(
            getImage("yes")
            ,
            getImage("no")
            //,getImage("idk")
            )
    ,
    newKey("idk", "Escape", "Enter")
        .selector("reson_prac_q")
        .callback(
            getSelector("reson_prac_q").select(getKey("idk"))
            )
    ,
    newText("spacer", "<p> </p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    getSelector("reson_prac_q")
        .wait(getSelector("reson_prac_q").test.selected())
        .log("last")
    ,
    newButton("next", "Good job!")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    /*,
    newTimer("3", 400)
        .start()
        .wait()
    ,
    newText("practice2", "<p>Here is another practice trial.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    getButton("cont")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    getText("question")
        .settings.center()
        .print()
    ,
    newAudio("two", "PRACTICE_2_D.ogg")
        .settings.center()
        .play()
        //.remove()
    ,
    getAudio("two").test.hasPlayed() 
        .wait()
        .remove()
    ,
    getCanvas("reson_prac_canvas")
        .center()
        .print()
    ,
    newSelector("reson_prac_q2")
        .add(
            getImage("yes")
            ,
            getImage("no")
            //,getImage("idk")
            )
    ,
    newKey("idk2", "Escape")
        .selector("reson_prac_q2")
        .callback(
            getSelector("reson_prac_q2").select(getKey("idk2"))
            )
    ,
    getSelector("reson_prac_q2")
        .wait(getSelector("reson_prac_q2").test.selected())
        .log("last")
    ,
    getText("spacer").center().print()
    ,
    getButton("next")
        .center()
        .print()
        .wait()
        */
    ).log("id", getVar("subjID"))

newTrial("RecogPractice",
    newTimer("1", 400)
        .start()
        .wait()
    ,
    newText("practice", "<p>Let's start with a practice trial. <strong>You will only hear the laugh once.</strong></p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align","center")
        .print()
    ,
    newText("practice2", "You can tell us the <strong>color</strong> of the person who was laughing, or <strong>point</strong> to the person who was laughing and your parent can tell us who you pointed to. You can also say 'I don't know' or I'm not sure.'")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newText("spacer", "<p></p>")
        .center()
        .print()
    ,
    newButton("cont", "LET'S PRACTICE!")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    newTimer("2", 400)
        .start()
        .wait()
    ,
    newText("question", "<p>Who was laughing?</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newAudio("one", "PRACTICE_1_A.ogg")
        .settings.center()
        .print()
        .once()
        //.play()
        .wait()
        .remove()
        //.remove()
    ,
    getAudio("one").test.hasPlayed() 
        //.wait()
        //.remove()
    ,
    getText("spacer")
        .center()
        .print()
    ,
    defaultImage.size(150, 180)
    ,
    /*newImage("idk", "dontknow_question.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        .size("5vw", "5vh")
        .print()
    ,*/
    newImage("mean_image", labels[0])
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newImage("neutral_image", labels[1])
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newImage("nice_image", labels[2])
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        //.print()
    ,
    newCanvas("recog_prac_canvas", 600, 200)
        .add("center at 18%", "middle at 50%",  getImage("mean_image"))
        .add("center at 50%", "middle at 50%",  getImage("neutral_image"))
        .add("center at 82%", "middle at 50%",  getImage("nice_image"))
        //.add("right at 95%", "top at 100%",  getImage("idk"))
        .color("yellow")
        .cssContainer("border", "solid 2px black")
        .center()
        .print()
    ,
    newSelector("recog_prac_q")
        .add(
            getImage("mean_image")
            ,
            getImage("neutral_image")
            ,
            getImage("nice_image")
            //,getImage("idk")
            )
    ,
    newKey("idk", "Escape", "Enter")
        .selector("recog_prac_q")
        .callback(
            getSelector("recog_prac_q").select(getKey("idk"))
            )
    ,
    getSelector("recog_prac_q")
        .wait(getSelector("recog_prac_q").test.selected())
        .log("last")
    ,
    newText("spacer2", "<p> </p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newButton("next", "Great job!")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    /*,
    newTimer("3", 400)
        .start()
        .wait()
    ,
    newText("practice2", "<p>Here is another practice trial.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    getButton("cont")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    getText("question")
        .settings.center()
        .print()
    ,
    newAudio("two", "PRACTICE_2_D.ogg")
        .settings.center()
        .play()
        //.remove()
    ,
    getAudio("two").test.hasPlayed() 
        .wait()
        .remove()
    ,
    getCanvas("recog_prac_canvas")
        .center()
        .print()
    ,
    newSelector("recog_prac_q2")
        .add(
            getImage("mean_image")
            ,
            getImage("neutral_image")
            ,
            getImage("nice_image")
            //,getImage("idk")
            )
    ,
    newKey("idk2", "Escape")
        .selector("recog_prac_q2")
        .callback(
            getSelector("recog_prac_q2").select(getKey("idk2"))
            )
    ,
    getSelector("recog_prac_q2")
        //.log("last")
        .wait(getSelector("recog_prac_q2").test.selected())
        .log("last")
    ,
    getText("spacer").center().print()
    ,
    getButton("next")
        .center()
        .print()
        .wait()
    */
    ).log("id", getVar("subjID"))


// start screens
//ResonStart
newTrial("ResonStart",
    newTimer(400)
        .start()
        .wait()
    ,
    /*newText("explainBreaks", "<p>Okay, the activity is about to start! There is no rush to answer, but you can only listen to each laugh once. Please make sure your volume is turned up so you can hear the audio clearly.</p>") 
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("reson_q", "Remember, we will be asking you <strong>if you would like to play with the person who was laughing.</strong>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("instructions", "<p>Let us know when you are ready to start.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,*/
    newText("explainBreaks", "<p>Great job, let's play the real game. Are you ready?</p>") 
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("reson_q", "Remember, we will be asking you <strong>if you would like to play with the person who was laughing.</strong>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    /*newText("instructions", "Are you ready?")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newText("<p></p>")
        .center()
        .print()
    ,*/
    newButton("start", "START")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
        .wait()
)

//RecogStart
newTrial("RecogStart",
    newTimer(400)
        .start()
        .wait()
    ,
    /*newText("explainBreaks", "<p>Okay, the activity is about to start! There is no rush to answer, but you can only listen to each laugh once. Please make sure your volume is turned up so you can hear the audio clearly.</p>") 
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("recog_q", "Remember, we will be asking you to tell us <strong>who you think is laughing</strong>. If you point to the screen, please have your parent tell us the <strong>color</strong> of the person you chose.")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("instructions", "<p>Let us know when you are ready to start.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,*/
    newText("explainBreaks", "<p>Great job. Now, let's play the real game.</p>") 
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newButton("start", "START")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
        .wait()
)


// attention checkpoints
newTrial("ResonCheckpoint",
    newTimer("check", 400)
        .start()
        .wait()
    ,
    newText("keep_going", "<p>Thanks for paying such great attention! There's just a few more to go.</p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("reson_q", "Remember, we are asking you <strong>if you would like to play with the person who was laughing.</strong></p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newButton("continue", "LET'S GO!")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
        .wait()
)

newTrial("RecogCheckpoint",
    newTimer("check", 400)
        .start()
        .wait()
    ,
    newText("keep_going", "<p>Thanks for paying such great attention! There's just a few more to go.</p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("recog_q", "Remember, we are asking you to tell us <strong>who you think is laughing.</strong></p>")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("recog_q", "Remember, we are asking you to tell us <strong>who you think is laughing</strong>. Please tell us the <strong>color</strong> of the person, or please have your parent tell us the person you <strong>point</strong> to.")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,*/
    newButton("continue", "LET'S GO!")
        .css("font-size", "1.5em")
        .css("text-align", "center")
        .settings.center()
        .print()
        .wait()
)


// regular experiment trials
Template ("LaughsGrouped_Child_ed.csv", variable =>
    //RESON TRIAL
    newTrial("ResonExperiment",
        newTimer(400)
            .start()
            .wait()
        ,
        newVar("Res_runningOrder", 0).global().set( v=>v+1 )
        ,
        newText("reson_question", "<p>Do you want to play with this person?</p>")
            .css("font-size", "1.5em")
            .settings.center()
            .print()
        ,
        newAudio("reson_laugh", ""+variable.originalFileName)
            .settings.center()
            .once()
            .print()
            //.play()
        ,
        getAudio("reson_laugh").test.hasPlayed() 
            .wait()
            .remove()
        ,
        defaultImage.size(180, 180)
        ,
        /*newImage("idk", "dontknow_question.png")
            .cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            .size("5vw", "5vh")
            .print()
        ,*/
        newImage("yes", "yes_check.png")
            //.cssContainer("border", "solid 2px green")
            .cssContainer("background-color", "white")
            //.print()
        ,
        newImage("no", "no_cross.png")
            //.cssContainer("border", "solid 2px red")
            .cssContainer("background-color", "white")
            //.print()
        ,
        newCanvas("reson_canvas", 600, 200)
            .add("center at 30%", "middle at 50%",  getImage("yes"))
            .add("center at 70%", "middle at 50%",  getImage("no"))
            //.add("right at 95%", "bottom at 95%",  getImage("idk"))
            //.color("black")
            //.cssContainer("border", "solid 2px blue")
            .center()
            .print()
        ,
        newSelector("reson_task_q")
            .add(
                getImage("yes")
                ,
                getImage("no")
                //,
                //getImage("idk")
                )
        ,
        newKey("idk", "Escape", "Enter")
            //.selector("reson_task_q")
            .callback(
                getSelector("reson_task_q").select(getKey("idk"))
                )
        ,   
        getSelector("reson_task_q")
            .add(getKey("idk"))
            .wait(getSelector("reson_task_q").test.selected()
                /*.failure(
                    //getKey("idk").test.pressed()
                    )
                .success(
                    getSelector("reson_task_q").log("last")
                    )*/
                )
            .log("last")
        )
    .log("fileName", variable.fileName)
    .log("scale", variable.scale)
    .log("bin", variable.bin)
    .log("laughNum", variable.laughNum)
    .log("id", getVar("subjID"))
    .log( "Res_runningOrder" , getVar("Res_runningOrder") )
)

Template ("LaughsGrouped_Child_ed.csv", variable => 
    //RECOG TRIAL
    newTrial("RecogExperiment", 
        newTimer(400)
            .start()
            .wait()
        ,
        newVar("Rec_runningOrder", 0).global().set( v=>v+1 )
        ,
        newText("recog_question", "<p>Who was laughing?</p>")
            .css("font-size", "1.5em")
            .settings.center()
            .print()
        ,
        newAudio("recog_laugh", ""+variable.originalFileName)
            .settings.center()
            //.play()
            .once()
            .print()
        ,
        getAudio("recog_laugh").test.hasPlayed() 
            .wait()
            .remove()
        ,
        defaultImage.size(150, 180)
        ,
        /*newImage("idk", "dontknow_question.png")
            .cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            .size("5vw", "5vh")
            .print()
        ,*/
        newImage("mean_image", labels[0])
            //.cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            .print()
        ,
        newImage("neutral_image", labels[1])
            //.cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            .print()
        ,
        newImage("nice_image", labels[2])
            //.cssContainer("border", "solid 2px black")
            .cssContainer("background-color", "white")
            .print()
        ,
        newCanvas("recog_canvas", 600, 200)
            .add("center at 18%", "middle at 50%",  getImage("mean_image"))
            .add("center at 50%", "middle at 50%",  getImage("neutral_image"))
            .add("center at 82%", "middle at 50%",  getImage("nice_image"))
            //.add("right at 95%", "top at 100%",  getImage("idk"))
            //.color("black")
            //.cssContainer("border", "solid 2px blue")
            .center()
            .print()
        ,
        newSelector("recog_task_q")
            .add(
                getImage("mean_image")
                ,
                getImage("neutral_image")
                ,
                getImage("nice_image")
                )
        ,
        newKey("idk", "Escape", "Enter")
            .selector("recog_task_q")
            .callback(
                getSelector("recog_task_q").select(getKey("idk"))
                )
        ,
        getSelector("recog_task_q")
            .wait(getSelector("recog_task_q").test.selected()
                /*.failure(
                    //getKey("idk").test.pressed()
                    )
                .success(
                    getSelector("recog_task_q").log("last")
                    )*/
                )
            .log("last")
        )
    .log("fileName", variable.fileName)
    .log("scale", variable.scale)
    .log("bin", variable.bin)
    .log("laughNum", variable.laughNum)
    .log("id", getVar("subjID"))
    .log( "Rec_runningOrder" , getVar("Rec_runningOrder") )
    .log("group", getVar("group_l"))
    
    //.log("test2", cond_label)
    //.log("group", getVar("order"))
)


// end of task generic trial
newTrial("TaskEnd",
    newText("conclusion", "<p>Great job!</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newButton("continue", "CONTINUE")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
)

//Finish page
newTrial("Finish",
    SendResults()
    ,
    newText("Nice job! Thank you very much for doing this activity with us!") 
        .center()
        .css("text-align", "center")
        .css("font-size", "2.0em")
        .print()
    ,
    /*newText("code", "Your completion code is:")
        .center()
        .css("font-size", "1.5em")
        .print()
    ,
    newText("displayid", idnum.toString(10))
        .center()
        .css("font-size", "1.5em")
        .print()
    ,*/
    newText("nexttask", "<p>Now, let's move on to the next game.</p>")
        .center()
        .css("text-align", "center")
        .css("font-size", "1.5em")
        .print()
    ,
    newButton("next", "NEXT")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    //,newButton("End").wait()
)

//color test (with selectable icons)
/*newTrial("ColorTest",
    newTimer(400)
        .start()
        .wait()
    ,
    newText("colortest_intro", "<p>Great! This game will also use colorful pictures, so let's make sure you can see the colors okay.</p>")
        .css("font-size", "2.0em")
        .settings.center()
        .print()
    ,
    newText("color", "Please answer a few questions to make sure you are familiar with the colors used for this activity.")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newButton("ok", "OK!") 
        .css("font-size", "1.0em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("black_q", "Click on the picture drawn in BLACK.")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    newButton("next", "Next Question!")
        .css("font-size", "1.0em")
        .center()
        .hidden()
    ,
    newText("warning", "Wrong. Please try again.")
        .center()
        .color("red")
        .hidden()
    , 
    newText("correct", "That's right! Great job!")
        .center()
        .color("green")
        .hidden()
    ,
    defaultImage.size("20vw","25vh")
    ,
    newImage("blue_image", "man1_blue.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        .print()
    ,
    newImage("black_image", "man2_black.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        .print()
    ,
    newImage("green_image", "man3_green.png")
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
        .print()
    ,
    newCanvas("canvas1", "75vw", "30vh")
        .add("center at 15%", "middle at 50%",  getImage("blue_image"))
        .add("center at 50%", "middle at 50%",  getImage("black_image"))
        .add("center at 85%", "middle at 50%",  getImage("green_image"))
        .color("orange")
        .cssContainer("border", "solid 2px black")
        .center()
        .print()
    ,
    newSelector("q1")
        .add(
            getImage("blue_image")
            ,
            getImage("black_image")
            ,
            getImage("green_image")
            )
        .shuffle()
    ,
    getSelector("q1")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("q1")
                .test.selected(getImage("black_image"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").hidden().remove()
    ,
    getImage("green_image").remove()
    ,
    getImage("blue_image").remove()
    ,
    getButton("next")
        .visible()
        .print()
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()
    ,
    newText("green_q", "Click on the picture drawn in GREEN.")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    getCanvas("canvas1").print()
    ,
    newSelector("q2")
        .add(
            getImage("blue_image")
            ,
            getImage("black_image")
            ,
            getImage("green_image")
            )
        .shuffle()
    ,
    getSelector("q2")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("q2")
                .test.selected(getImage("green_image"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").settings.hidden().remove()
    ,
    getImage("black_image").remove()
    ,
    getImage("blue_image").remove()
    ,
    getButton("next")
        .visible()
        .print()
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()
    ,
    newText("blue_q", "Click on the picture drawn in BLUE.")
        .css("font-size", "1.5em")
        .settings.center()
        .print()
    ,
    getCanvas("canvas1").print()
    ,
    newSelector("q3")
        .add(
            getImage("blue_image")
            ,
            getImage("black_image")
            ,
            getImage("green_image")
            )
        .shuffle()
    ,
    getSelector("q3")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning").visible().print()
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
        .wait(
            getSelector("q3")
                .test.selected(getImage("blue_image"))
            )
    ,
    getText("correct").visible().print()
    ,
    getText("warning").settings.hidden().remove()
    ,
    getImage("green_image").remove()
    ,
    getImage("black_image").remove()
    ,
    getButton("next")
        .visible()
        .print()
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()
    ,
    newText("startText", "<p>You will now begin the tasks and questionnaires. Click the START button to begin.</p>")
        .center()
        .print()
    ,
    newButton("start", "START")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
)*/

//color test (with buttons, formatted)
newTrial("ColorTest",
    newTimer(400)
        .start()
        .wait()
    ,
    newText("great", "<p>Great!</p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("colortest_intro", "This game will also use colorful pictures, so let's make sure you can see the colors okay.")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("spacer", "<p> </p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
    ,getText("spacer").center().print()
    ,
    newButton("ok", "OK!") 
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("what", "<p>What color is this person's shirt?</p>")
        .css("font-size", "2.0em")
        .settings.center()
        .print()
        //.print("center at 50vw", "middle at 25vh")
    ,
    //getText("spacer").center().print()
    //,
    newButton("next", "Next Question!")
        .css("font-size", "1.5em")
        .center()
        .hidden()
    ,
    newText("warning", "<p> Wrong. Please try again. </p>")
        .css("font-size", "1.5em")
        .center()
        .color("red")
        .hidden()
    , 
    newText("correct", "<p> That's right! Great job! </p>")
        .css("font-size", "1.5em")
        .center()
        .color("green")
        .hidden()
    ,
    defaultImage.size(150, 180)
    ,
    newImage("blue_image", "man1_blue.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newImage("black_image", "man2_black.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newImage("green_image", "man3_green.png")
        .center()
        .cssContainer("border", "solid 2px black")
        .cssContainer("background-color", "white")
    ,
    newButton("black_b", "BLACK")
        .css("font-size", "1.5em")
    ,
    newButton("green_b", "GREEN")
        .css("font-size", "1.5em")
    ,
    newButton("blue_b", "BLUE")
        .css("font-size", "1.5em")
    ,
    getImage("black_image").print(/*"center at 50vw", "middle at 45vh"*/)
    ,
    getText("spacer").center().print()
    ,
    getButton("black_b")
        .print()
        //.print("center at 20vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("green_b")
        .print()
        //.print("center at 50vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("blue_b")
        .center()
        .before(getButton("black_b"))
        .after(getButton("green_b"))
        //.center()
        .print()
        //.print("center at 80vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("black_b").wait()
    ,
    getText("correct")
        .visible()
        .center()
        .print()
        //.print("center at 50vw", "middle at 75vh")
    ,
    getText("warning").hidden().remove()
    ,
    
    getButton("next")
        .visible()
        .center()
        .print()
        //.print("center at 50vw", "middle at 82vh")
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()
    ,
    getText("what")
        .center()
        .print()
    ,
    getImage("green_image").print(/*"center at 50vw", "middle at 45vh"*/)
    ,
    getText("spacer").center().print()
    ,
    getButton("black_b")
        //.print()
        //.print("center at 20vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("green_b")
        //.print()
        //.print("center at 50vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("blue_b")
        .center()
        .before(getButton("black_b"))
        .after(getButton("green_b"))
        .print()
        //.print("center at 80vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("green_b").wait()
    ,
    getText("correct")
        .visible()
        .center()
        .print()
        //.print("center at 50vw", "middle at 75vh")
    ,
    getText("warning").hidden().remove()
    ,
    getButton("next")
        .visible()
        .center()
        .print()
        //.print("center at 50vw", "middle at 82vh")
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()
    ,
    getText("what")
        .center()
        .print()
    ,
    getImage("blue_image").print(/*"center at 50vw", "middle at 45vh"*/)
    ,
    getText("spacer").center().print()
    ,
    getButton("black_b")
        //.print()
        //.print("center at 20vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("green_b")
        //.print("center at 50vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("blue_b")
        .center()
        .before(getButton("black_b"))
        .after(getButton("green_b"))
        .print()
        //.print("center at 80vw", "middle at 65vh")
        .callback(
            getText("correct").test.printed()
                .failure(
                    getText("warning")
                        .visible()
                        .center()
                        .print()
                        //.print("center at 50vw", "middle at 75vh")
                    )
                .success(
                    getText("warning").hidden().remove()
                    )
            )
    ,
    getButton("blue_b").wait()
    ,
    getText("correct")
        .visible()
        .center()
        .print()
        //.print("center at 50vw", "middle at 75vh")
    ,
    getText("warning").hidden().remove()
    ,
    getButton("next")
        .visible()
        .center()
        .print()
        //.print("center at 50vw", "middle at 82vh")
        .wait()
        .hidden()
    ,
    getText("correct").hidden().remove()
    ,
    clear()
    ,
    newText("well_done", "<p>Great job! Now let's head to the Laughing Game.</p>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .center()
        .print()
    ,
    newButton("start", "START")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
)