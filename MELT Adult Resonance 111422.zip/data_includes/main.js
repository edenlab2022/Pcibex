PennController.ResetPrefix(null)

DebugOff()

Header(
  newVar("runningOrder", 0).global().set( v=>v+1 )
)
.log( "runningOrder" , getVar("runningOrder") )

// ASSIGN VARS
//set up and trials
var prep = seq("loadKeys", "Intro")
var firstthingsfirst = seq("loadKeys", "MusicAudioTest", "EmoDescription")
var musicTaskRec = seq("loadKeys", "StartMusicRecog", "PracticeEmoMusic", "BreakEmoMusic", randomize("ExperimentalEmoMusic_Recognition"))
var musicTaskRes = seq("loadKeys", "StartMusicReson", "PracticeEmoMusic_1", "BreakEmoMusic", randomize("ExperimentalEmoMusic_Resonance"))
var srp = seq("SRP")
var mlq = seq("MLQ")
var roughArr = randomizeTasks(musicTaskRec, musicTaskRes)
var qs = randomizeTasks(srp, mlq)
var finalArr = seq(prep, firstthingsfirst, musicTaskRes, "Transition", qs[0], "Transition", qs[1])


//var color_order = Math.floor(Math.random() * 24)
//var groups = createColorGroup(color_order)
//var leftColor = groups[0] + ""
//var centerLeftColor = groups[1] + ""
//var centerRightColor = groups[2] + ""
//var rightColor = groups[3] + ""
//var color_order_label = groups[4] + ""

// GENERATE RANDOM ID
var idnum = Math.floor((Math.random() * 10000) + 1)

SetCounter("counter", "inc", 1);

newTrial("genID",
    newVar("subjID")
        .global()
        .set(idnum)
)
.log("id", getVar("subjID"))

Sequence("counter", "genID", "Consent", "Demographics", finalArr, "TaskEnd")

function randomizeTasks(one, two) {
    var temp = [one, two]; 
    var allArr = [two, one];
    
    //random num, either 0 or 1
    var number = Math.floor(Math.random() * 2);
    
    if (number == 0) {
        return temp;
    }
    else {
        return allArr;
    }

    return allArr;
} 
 

/*
function createColorGroup(int) {
    var blgbr = ["blue", "green", "black", "red", "blgbr"]; //1
    var blgrb = ["blue", "green", "red", "black", "blgrb"]; //2
    var blbgr = ["blue", "black", "green", "red", "blbgr"]; //3
    var blbrg = ["blue", "black", "red", "green", "blbrg"]; //4
    var blrgb = ["blue", "red", "green", "black", "blrgb"]; //5
    var blrbg = ["blue", "red", "black", "green", "blrbg"]; //6
    var gblbr = ["green", "blue", "black", "red", "gblbr"]; //7
    var gblrb = ["green", "blue", "red", "black", "gblrb"]; //8
    var gbblr = ["green", "black", "blue", "red", "gbblr"]; //9
    var gbrbl = ["green", "black", "red", "blue", "gbrbl"]; //10
    var grblb = ["green", "red", "blue", "black", "grblb"]; //11
    var grbbl = ["green", "red", "black", "blue", "grbbl"]; //12
    var bblgr = ["black", "blue", "green", "red", "bblgr"]; //13
    var bblrg = ["black", "blue", "red", "green", "bblrg"]; //14
    var bgblr = ["black", "green", "blue", "red", "bgblr"]; //15
    var bgrbl = ["black", "green", "red", "blue", "bgrbl"]; //16 
    var brblg = ["black", "red", "blue", "green", "brblg"]; //17
    var brgbl = ["black", "red", "green", "blue", "brgbl"]; //18
    var rblgb = ["red", "blue", "green", "black", "rblgb"]; //19
    var rblbg = ["red", "blue", "black", "green", "rblbg"]; //20
    var rgblb = ["red", "green", "blue", "black", "rgblb"]; //21
    var rgbbl = ["red", "green", "black", "blue", "rgbbl"]; //22
    var rbblg = ["red", "black", "blue", "green", "rbblg"]; //23
    var rbgbl = ["red", "black", "green", "blue", "rbgbl"]; //24
    
    var groups = [rbgbl, rbblg, rgbbl, rgblb, rblbg, rblgb,
    brgbl, brblg, bgrbl, bgblr, bblrg, bblgr,
    grbbl, grblb, gbrbl, gbblr, gblrb, gblbr, 
    blrbg, blrgb, blbrg, blbgr, blgrb, blgbr];
    
    return groups[int]; 
}

// color order var generation
newTrial("color_order",
    newVar("colorOrder")
        .global()
        .set(color_order_label)
).log("id", getVar("subjID"))
.log("color_group", color_order_label)
*/

newTrial("Consent",
    defaultText
        .print()
    ,
    newText("<p><strong>University of Pennsylvania Informed Consent for Behavioral Studies Involving Adults</strong></p> ")
        .css("font-size", "2em")
        .center()
    ,
    newText("<p><strong>Note that this study is not compatible with Safari. If you are using Safari, please copy the link and open it in a different browser (e.g., Firefox or Internet Explorer)</strong>")
        .css("font-size", "2em")
        .center()
    ,
    newText("<p>Title of Research Study: Social Processing, Affiliation, and Relationships </p>")
        .css("font-size", "1.5em")
    ,
    newText("<p>Principal Investigator: Rebecca Waller, Ph.D., 425 S. University Avenue, Stephen A. Levin Building, Room 465 Philadelphia PA 19104</p>")
        .css("font-size", "1.5em")
    ,
    newText("<p>Protocol #: 832034</p>")
        .css("font-size", "1.5em")
    ,
    newText("<p>Phone: 215-573-2201 Email: rwaller@sas.upenn.edu</p>")
        .css("font-size", "1.5em")
    ,
    newText("<p>You are invited to take part in a research study run by Dr. Rebecca Waller from Department of Psychology at the University of Pennsylvania. Your participation is voluntary, which means you can choose whether or not to participate. Whether you decide to participate or not, there will be no loss of benefits to which you are otherwise entitled. Before you make a decision you will need to know the purpose of the study, the possible risks and benefits of being in the study and what you will have to do if decide to participate. If you do not understand what you are reading, do not consent to participate.</p>")
    ,
    newText("<p><strong>What is the purpose of the study?</strong></p>")
    ,
    newText("<p>The purpose of the study is to learn about how adults process and respond to different emotional stimuli, how they understand and process aspects of relationships, and how they respond in different social situations.</p>")
    ,
    newText("<p><strong>Why was I asked to participate in the study?</strong></p>")
    ,
    newText("<p>You are being asked to join the study because you are an adult. Your participation will help us to understand emotional processing, social behaviors, and different aspects of social relationship understanding in adulthood.</p>")
    ,
    newText("<p><strong>How long will I be in the study?</strong></p>")
    ,
    newText("<p>This study will take approximately 30 minutes. Your participation will last the duration of that time.</p>")
    ,
    newText("<p><strong>Where will the study take place?</strong></p>")
    ,
    newText("<p>The study will be conducted online.</p>")
    ,
    newText("<p><strong>What will I be asked to do?</strong></p>")
    ,
    newText("<p>In this study, you will complete computerized questionnaires that assess your emotional sensitivity and relationship processing. You may also be asked to complete computerized emotion processing tasks or games, or rate different emotional stimuli.</p>")
    ,
    newText("<p><strong>What are the risks?</strong></p>")
    ,
    newText("<p>The risks are minimal. Some of the questionnaires ask questions that are personal in nature and may cause slight discomfort. This information is kept confidential. You are able to stop participating at any time.</p>")
    ,
    newText("<p><strong>How will I benefit from the study?</strong></p>")
    ,
    newText("<p>There is no direct benefit to participating in this study. However, your participation could help us understand and improve our knowledge about how our emotions impact our relationships with other people. If you complete the HIT and your HIT is approved you will be compensated at a rate of $12/hour (e.g., $6 for a 30 minute study) for your time. Payments are made via Amazon’s payment system.</p>")
    ,
    newText("<p><strong>What happens if I do not choose to join the research study?</strong></p>")
    ,
    newText("<p>Your participation is voluntary and you will not be penalized if you choose not to join the research study.</p>")
    ,
    newText("<p><strong>When will I be done participating in this study?</strong></p>")
    ,
    newText("<p>You have the right to drop out of the research study at any time. There is no penalty if you decide to do so. After completing the research study, if you do not want your information to be used in analyses, please contact Dr. Waller at rwaller@sas.upenn.edu.</p>")
    ,
    newText("<p><strong>How will confidentiality be maintained and my privacy be protected?</strong></p>")
    ,
    newText("<p>The information collected in this study is for research purposes only, and is not considered medical or health information. We will make efforts to ensure that all information collected from this study is kept confidential. However, as this is an online study, confidentiality cannot be absolutely guaranteed. Importantly, we will <strong>not</strong> ask you for your name, phone number, or address. If information from this study is published or presented at scientific meetings, we will keep your IP address confidential. We may share anonymous data as a part of the publication process. All collected data is labeled by a code rather than by IP address. The master for the code and data are kept separately. In addition, any demographic information about you will be retained for subsequent reporting to funding agencies; this information will also be stored under a code. However, authorized representatives of the University of Pennsylvania Institutional Review Board (IRB), a committee charged with protecting the rights and welfare of research participants, may be provided access to research records that identify you by IP address. To ensure data security, data will be stored on a password-protected computer system. Only authorized members of our laboratory can access these files.</p>")
    ,
    newText("<p><strong>Will I be paid for being in this study?</strong></p>")
    ,
    newText("<p>As compensation for your participation, you will be compensated at a rate of $12/hour (e.g., $6 for a 30 minute study) for your approved HIT. Payments are made via Amazon’s payment system. Researchers have 3 days after you complete the HIT to approve your HIT. Please note: The University of Pennsylvania is required to report to the IRS any cumulative payments for participation in research studies that exceed a total of $600 in a calendar year.</p>")
    ,
    newText("<p><strong>Who can I call with questions, complaints or if I’m concerned about my rights as a research participant?</strong></p>")
    ,
    newText("<p>If you have questions, concerns or complaints regarding your participation in this research study or if you have any questions about your rights as a research participant, you should email the lead researcher on this study, Dr. Rebecca Waller (rwaller@sas.upenn.edu). If a member of the research team cannot be reached or you want to talk to someone other than those working on the study, you may contact the Office of Regulatory Affairs with any question, concerns or complaints at the University of Pennsylvania by calling (215) 898-2614. You may print out a copy of this consent form for your records.</p>")
    ,
    newText("<strong>Statement of electronic consent: </strong>Please select your choice below. You may print a copy of this consent form for your records. Clicking on the “AGREE” button indicates that: You have read and understand the above information. You voluntarily agree to participate. You are 18 years of age or older.")
    ,
   newScale("consent", "&nbspAGREE&nbsp&nbsp&nbsp&nbsp", "DISAGREE (this will terminate the experiment)") 
        .center()
        .once()
        .radio()
        .labelsPosition("top")
        .print()
        .callback(
            getScale("consent").test.selected("DISAGREE (this will terminate the experiment)")
            .success(clear())
            .failure(getButton("continue").settings.visible())
        )
    ,
    newText("blank_c", "<p> </p>")
        .print()
    ,
    newButton("continue", "CONTINUE")
        .center()
        .print()
        .hidden()
        .wait()
)
.log("id", getVar("subjID"))


                                                                            // GENERATE I

                                                                            
                                                                            //DEMOGRAPHICS

newTrial("Demographics",
    newText("<p>Thank you for taking part in our study. First, we have a few basic questions before you complete the experiment.</p>")
        .center()
        .css("text-align","center")
        .css("font-size", "1.5em")
        .print()
    ,
    newButton("continue_8", "CONTINUE")
        .center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("<p>What is your gender?</p>")
        .center()
        .print()
    ,
    newScale("gender", "Male", "Female", "Other", "Prefer not to say")
        .vertical()
        .center()
        .labelsPosition("right")
        .log()
        .print()
        .wait()
    ,
    newText("<p>What is your race?</p>")
        .center()
        .print()
    ,
    newScale("race", "White/Caucasian", "Black/African American", "Asian", "Hispanic or Latino of Spanish Origin", "American Indian or Alaska Native", "Native Hawaiian or Pacific Islander", "Other", "Prefer not to say")
        .vertical()
        .center()
        .labelsPosition("right")
        .log()
        .print()
        .wait()
    ,
    newText("<p>What is the highest education you've completed?</p>")
        .center()
        .print()
    ,
    newScale("education", "High School", "GED", "Some college", "Bachelor's Degree", "Graduate Degree")
        .vertical()
        .center()
        .labelsPosition("right")
        .log()
        .print()
        .wait()
    ,
    newText("<p>Please enter your age and hit return/enter.</p>")
        .center()
        .print()
    ,
    newTextInput("age")
        .center()
        .log("final")
        .print()
        .wait()
    ,
    newText("blank_2", "<p> </p>")
        .print()
    ,
    newText("error", "Please enter a numerical value for your age.") 
        .center()
        .color("red")
        .print()
        .hidden()
    ,
    newText("blank_3", "<p> </p>")
        .print()
    ,
    newButton("continue_9", "CONTINUE")
        .center()
        .print()
        .callback(
            getTextInput("age").test.text( /^\d+$/ )
            .success(getText("error").settings.hidden())
            .failure(getText("error").settings.visible())
        )
    .wait(getTextInput("age").test.text(( /^\d+$/ ))
    ,
    clear()
    ,
    newText("startText", "<p>You will now begin the tasks and questionnaires. Click the START button to begin.</p>")
        .center()
        .print()
    ,
    newButton("start", "START")
        .center()
        .print()
        .wait()
))
.log( "id" , getVar("subjID"))

// STUDY INTRO 
newTrial("Intro", 
    newText("intro", "<p><strong>Welcome to the Music Game!</strong>")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    /*newText("test", color_order_label + "")
        .center()
        .print()
    ,*/
    newButton("continue", "CONTINUE")
        .center()
        .print()
        .wait()
)

newTrial("EmoDescription",
    newText("emotypes", "You will listen to music clips and answer some questions about music and emotions. Here are the emotion options that will be used throughout this task:")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    defaultImage.size(140, 190)
    ,
    newText("blank_4", "<p> </p>")
        .print()
    ,
    newCanvas("tobeclear", 1800, 200)
            .add("center at -5%", "middle at 50%", newImage("happyImage", "happylabel.jpg"))
            .add("center at 17%", "middle at 50%", newImage("sadImage", "sadlabel.jpg"))
            .add("center at 39%", "middle at 50%", newImage("calmImage", "calmlabel.jpg"))
            .add("center at 61%", "middle at 50%", newImage("angryImage", "angrylabel.jpg"))
            .add("center at 83%", "middle at 50%", newImage("fearImage", "fearlabel.jpg"))
            .add("center at 105%", "middle at 50%", newImage("noneImage", "NoneOption.jpg"))
            .print()
    ,
    newText("blank_5", "<p> </p>")
        .print()
    ,
    newText("go_1", "Press the CONTINUE button to proceed.")
        .css("font-size", "1.25em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("blank_6", "<p> </p>")
        .print()
    ,
    newButton("goon_1", "CONTINUE")
        .center()
        .print()
        .wait()
)

/*newTrial("PrePrac",
    newText("emty", "In this task you will listen to music clips and identify the emotion conveyed by the music. You will now do a practice trial.")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("blank_7", "<p> </p>")
        .print()
    ,
    newText("go", "Press the CONTINUE button to proceed.")
        .css("font-size", "1.25em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("blank_8", "<p> </p>")
        .print()
    ,
    newButton("goon", "CONTINUE")
        .center()
        .print()
        .wait()
)

newTrial("PrePrac_1",
    newText("emty1", "In this task you will listen to music clips and identify what emotion the music makes you feel. You will now do a practice trial.")
        .css("font-size", "2.0em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("blank_9", "<p> </p>")
        .print()
    ,
    newText("go_2", "Press the CONTINUE button to proceed.")
        .css("font-size", "1.25em")
        .css("text-align", "center")
        .settings.center()
        .print()
    ,
    newText("blank_10", "<p> </p>")
        .print()
    ,
    newButton("goon_2", "CONTINUE")
        .center()
        .print()
        .wait()
)*/

newTrial("MusicAudioTest",
    newText("instructions", "<p>Please make sure your volume is on. Listen to the audio and type the word you hear into the box below. Click the VERIFY button to verify your answer and proceed.</p>")
        .css("font-size", "1.5em")
        .settings.center()
        .css("text-align", "center")
        .print()
    ,
    newAudio("book", "Book.ogg")
        .settings.center()
        .print()
        .log("play")
        .log("end")
        .wait()
    ,
    newText("spacer", "<p> </p>")
        .settings.center()
        .print()
    ,
    getText("spacer")
        .settings.center()
        .print()
    ,
    newTextInput("keyword")
        .settings.center()
        .print()
    ,
    getText("spacer")
        .settings.center()
        .print()
    ,
    newText("warning", "Please try again. Make sure the word is spelled correctly and there are no extra spaces in the box.") 
        .center()
        .color("red")
        .print()
        .hidden()
    ,
    getText("spacer")
        .settings.center()
        .print()
    ,
    newText("verifyText", "Click VERIFY to check your answer.") 
        .center()
        .print()
    ,
    newButton("verify", "VERIFY")
        .print()
        .center()
        .callback(
            getTextInput("keyword").test.text("book").or(getTextInput("keyword").test.text("BOOK")).or(getTextInput("keyword").test.text("Book"))
            .success(getText("warning").settings.hidden())
            .failure(getText("warning").settings.visible())
        )
        
        .wait(getTextInput("keyword").test.text("book").or(getTextInput("keyword").test.text("BOOK")).or(getTextInput("keyword").test.text("Book")))
    )

newTrial("StartMusicRecog", 
    newText("One", "<p>In this task you will listen to music clips and identify the emotion conveyed by the music.")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    newText("Two", "Before you begin, you will complete a few practice trials.<p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newButton("continue_111", "CONTINUE")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    ,
    //newVar("trialOrderRec", 0)
        //.global()
        //.set(0)
)

newTrial("StartMusicReson", 
    newText("One", "<p>In this task you will listen to music clips and identify what emotion the music makes you feel. There are no right or wrong answers.")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    newText("Two", "Before you begin, you will complete a few practice trials.<p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newButton("continue_1", "CONTINUE")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    ,
    //newVar("trialOrderRes", 0)
        //.global()
        //.set(0)
)

            //START PRACTICE TRIALS
Template(
    GetTable("emoMusicGroupedPracticeV2.csv")
    ,
    row => newTrial("PracticeEmoMusic",
        newAudio(row.audiofile)
            .center()
            //.play()
            .play("once")
            .wait() 
        ,clear()
        ,
        newText("Q", "<p>Which emotion face best matches the emotion conveyed by the music?</p>")
            .center()
            .css("text-align","center")
            .css("font-size", "1.5em")
            .print()
        ,
        newSelector("eugenies")
            .once()
            .frame("dashed 0px white")
        ,
        defaultImage.size(140, 190)
        ,
        newImage("sadImage", "sadlabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("happyImage", "happylabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("calmImage", "calmlabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("angryImage", "angrylabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("fearImage", "fearlabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("noneImage", "NoneOption.jpg")
            .selector("eugenies")
        ,
        newCanvas("eugenieslabelsrecogprac", 1800, 200)
            .add("center at -5%", "middle at 50%", getImage("sadImage"))
            .add("center at 17%", "middle at 50%", getImage("happyImage"))
            .add("center at 39%", "middle at 50%", getImage("calmImage"))
            .add("center at 61%", "middle at 50%", getImage("angryImage"))
            .add("center at 83%", "middle at 50%", getImage("fearImage"))
            .add("center at 105%", "middle at 50%", getImage("noneImage"))
            //.color("yellow")
            //.cssContainer("border", "solid 2px black")
            .print()
        ,
        /*newKey("idk", "Escape", "Enter")
            .selector("eugenies")
            .callback(
                getSelector("eugenies").select(getKey("idk"))
                )
        ,*/
        getSelector("eugenies")
            .wait()
            .log("last")
        ,
        newText("correct", "Great job!<p>")
            .css("font-size", "1.5em")
            .center()
            .color("green")
            .print()
        ,
        /*newText("Press space to continue.")
            .css("font-size", "1.5em")
            .center()
            .print()
        ,
        newKey(" ")
            .wait()
        ,
        clear()*/
        newButton("next", "NEXT").center().print()
    )
    .log("id", getVar("subjID"))
    .log("audiofile", row.audiofile)
    .log("correctanswer", row.correctanswer)
    .log("ExpGroup", row.Group)
)

newTrial("Transition0",
    newText("conclusion0", "<p>Nice work! In this next task, the instructions will change. Please make sure that you read the instructions carefully so that you are able to complete the task.</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    newButton("cont", "CONTINUE")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
)

newTrial("Transition",
    newText("conclusion", "<p>Nice work! Let's go on to the next task.</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newButton("cont", "CONTINUE")
        .css("font-size", "1.5em")
        .center()
        .print()
        .wait()
)

// pre-experimental trial screen  
newTrial("BreakEmoMusic",
    newText("1", "<p>Great job! Now we will start the real game. Are you ready?</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    /*newText("2", "<p>Press the START button when ready.</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,*/
    newButton("start", "START")
        .settings.center()
        .css("font-size", "1.5em")
        .print()
        .wait()
    )


// experimental trials
Template(
    GetTable("emoMusicExpGroupedV2.csv")
    ,
    row => newTrial("ExperimentalEmoMusic_Recognition",
        /*newVar("trialOrderRec", 0)
            .global()
            .set( v=>v+1 )
        ,*/
        getVar("trialOrderRec")
            .set( v=>v+1 )
            .log()
        ,
        newAudio(row.audiofile)
            .center()
            .play("once")
            //.play()
            .wait()
        ,clear()
        ,
        newText("Q", "<p>Which emotion face best matches the emotion conveyed by the music?</p>")
            .center()
            .css("text-align","center")
            .css("font-size", "1.5em")
            .print()
        ,
        newSelector("eugenies")
            .once()
            .frame("dashed 0px white")
        ,
        defaultImage.size(140, 190)
        ,
        newImage("sadImage", "sadlabel.jpg")
            .selector("eugenies")
        ,
        newImage("happyImage", "happylabel.jpg")
            .selector("eugenies")
        ,
        newImage("calmImage", "calmlabel.jpg")
            .selector("eugenies")
        ,
        newImage("angryImage", "angrylabel.jpg")
            .selector("eugenies")
        ,
        newImage("fearImage", "fearlabel.jpg")
            .selector("eugenies")
        ,
        newImage("noneImage", "NoneOption.jpg")
            .selector("eugenies")
        ,
        newCanvas("eugenieslabelsrecog", 1800, 200)
            .add("center at -5%", "middle at 50%", getImage("sadImage"))
            .add("center at 17%", "middle at 50%", getImage("happyImage"))
            .add("center at 39%", "middle at 50%", getImage("calmImage"))
            .add("center at 61%", "middle at 50%", getImage("angryImage"))
            .add("center at 83%", "middle at 50%", getImage("fearImage"))
            .add("center at 105%", "middle at 50%", getImage("noneImage"))
            .print()
        ,
        /*newKey("idk", "Escape", "Enter")
            .selector("eugenies")
            .callback(
                getSelector("eugenies").select(getKey("idk"))
                )
        ,*/
        getSelector("eugenies")
            .wait()
            .log("last")
        /*,
        newText("<p>Press space to continue.</p>")
            .css("font-size", "1.5em")
            .center()
            .print()
        ,
        newKey(" ")
            .wait()
        */
    )
                            //SAVING TRIAL INFORMATION
    .log("id", getVar("subjID"))
    .log("audiofile", row.audiofile)
    .log("correctanswer", row.correctanswer)
    .log("ExpGroup", row.Group)
    //.log("trialOrderRec", getVar("trialOrderRec"))
    
    //.log("RecIsFirst", getVar("trialOrderRes").test.is(getVar("trialOrderRec"))
        //? ["Recog First"] 
        //: ["Recog Second"] )
)

Template(
    GetTable("emoMusicGroupedPracticeV2.csv")
    ,
    row => newTrial("PracticeEmoMusic_1",
        newAudio(row.audiofile)
            .center()
            .play("once")
            //.play()
            .wait() 
        ,clear()
        ,
        newText("Q", "<p>How does the music make you feel?</p>")
            .center()
            .css("font-size", "1.5em")
            .print()
        ,
        newSelector("eugenies")
            .once()
            .frame("dashed 0px white")
        ,
        defaultImage.size(140, 190)
        ,
        newImage("sadImage", "sadlabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("happyImage", "happylabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("calmImage", "calmlabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("angryImage", "angrylabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("fearImage", "fearlabel.jpg")
            .selector("eugenies")
            //.cssContainer("border", "solid 2px black")
            //.cssContainer("background-color", "white")
            //.print()
            //.size(150, 200)
        ,
        newImage("noneImage", "NoneOption.jpg")
            .selector("eugenies")
        ,
        newCanvas("eugenieslabelsrecogprac", 1800, 200)
            .add("center at -5%", "middle at 50%", getImage("sadImage"))
            .add("center at 17%", "middle at 50%", getImage("happyImage"))
            .add("center at 39%", "middle at 50%", getImage("calmImage"))
            .add("center at 61%", "middle at 50%", getImage("angryImage"))
            .add("center at 83%", "middle at 50%", getImage("fearImage"))
            .add("center at 105%", "middle at 50%", getImage("noneImage"))
            //.color("yellow")
            //.cssContainer("border", "solid 2px black")
            .print()
        ,
        /*newKey("idk", "Escape", "Enter")
            .selector("eugenies")
            .callback(
                getSelector("eugenies").select(getKey("idk"))
                )
        ,*/
        getSelector("eugenies")
            .wait()
            .log("last")
        ,
        newText("correct", "Great job!<p>")
            .css("font-size", "1.5em")
            .center()
            .color("green")
            .print()
        ,
        /*newText("Press space to continue.")
            .css("font-size", "1.5em")
            .center()
            .print()
        ,
        newKey(" ")
            .wait()
        ,
        clear()*/
        newButton("next", "NEXT").center().print()
    )
    .log("id", getVar("subjID"))
    .log("audiofile", row.audiofile)
    .log("correctanswer", row.correctanswer)
    .log("ExpGroup", row.Group)
)

Template(
    GetTable("emoMusicExpGroupedV2.csv")
    ,
    row => newTrial("ExperimentalEmoMusic_Resonance",
        /*newVar("trialOrderRes", 0)
            .global()
            .set( v=>v+1 )
        ,*/
        //getVar("trialOrderRes")
            //.set( v=>v+1 )
            //.log()
        //,
        newAudio(row.audiofile)
            .center()
            .play("once")
            //.play()
            .wait()
        ,clear()
        ,
        newText("Q", "<p>How does the music make you feel?</p>")
            .center()
            .css("font-size", "1.5em")
            .print()
        ,
        newSelector("eugenies")
            .once()
            .frame("dashed 0px white")
        ,
        defaultImage.size(140, 190)
        ,
        newImage("sadImage", "sadlabel.jpg")
            .selector("eugenies")
        ,
        newImage("happyImage", "happylabel.jpg")
            .selector("eugenies")
        ,
        newImage("calmImage", "calmlabel.jpg")
            .selector("eugenies")
        ,
        newImage("angryImage", "angrylabel.jpg")
            .selector("eugenies")
        ,
        newImage("fearImage", "fearlabel.jpg")
            .selector("eugenies")
        ,
        newImage("noneImage4", "NoneOption.jpg")
            .selector("eugenies")
        ,
        newCanvas("eugenieslabelsreson", 1800, 200)
            .add("center at -5%", "middle at 50%", getImage("sadImage"))
            .add("center at 17%", "middle at 50%", getImage("happyImage"))
            .add("center at 39%", "middle at 50%", getImage("calmImage"))
            .add("center at 61%", "middle at 50%", getImage("angryImage"))
            .add("center at 83%", "middle at 50%", getImage("fearImage"))
            .add("center at 105%", "middle at 50%", getImage("noneImage4"))
            .print()
        ,
        /*newKey("idk", "Escape", "Enter")
            .selector("eugenies")
            .callback(
                getSelector("eugenies").select(getKey("idk"))
                )
        ,*/
        getSelector("eugenies")
            .wait()
            .log("last")
        /*,
        newText("<p>Press space to continue.</p>")
            .css("font-size", "1.5em")
            .center()
            .print()
        ,
        newKey(" ")
            .wait()
        */
    )
                            //SAVING TRIAL INFORMATION
    .log("id", getVar("subjID"))
    .log("audiofile", row.audiofile)
    .log("correctanswer", row.correctanswer)
    .log("ExpGroup", row.Group)
    //.log("trialOrderRes", getVar("trialOrderRes"))
    //.log("ResIsFirst", getVar("trialOrderRec").test.is(getVar("trialOrderRes"))  
        //? ["Reson First"] 
        //: ["Reson Second"] 
    //)
)

// end of task generic trial
newTrial("TaskEnd",
    newText("conclusion", "<p>All done, great job! That is all we will do today. Thank you very much for doing this activity with us!</p>")
        .css("font-size", "1.5em")
        .css("text-align","center")
        .center()
        .print()
    ,
    newText("suggestions", "If you have any comments or suggestions about how we can improve this experiment, please enter them in the text entry box below.")
        .center()
        .css("text-align","center")
        .css("font-size", "1.5em")
        .print()
    ,
    newTextInput("suggest")
        .center()
        .print()
        .log("all")
    ,
    newText("bleeeenk", "<p> </p>")
        .print()
    ,
    newText("code", "Your completion code is:")
        .center()
        .css("font-size", "1.5em")
        .print()
    ,
    newText("displayid", idnum.toString(10))
        .center()
        .css("font-size", "1.5em")
        .print()
        .log()
    ,
    newButton("finish", "FINISH")
        .print()
        .center()
        .wait()
)
.log( "id" , getVar("subjID"))


newTrial("SRP",
    //newVar("questionnaireOrder")
        //.set( v=>v+1 )
        //.log()
    //,
    newText("<p>Please complete the following questionnaire:</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newText("<p>Please rate the degree to which you agree with the following statements.</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newText("score1", "1) I’m a rebellious person.")
        .center()
        .print()
    ,
    newText("blank7", "<p> </p>")
        .print()
    ,
    newScale("score1", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()   
        .wait()
        .log("last")
    ,
    newText("blank8", "<p> </p>")
        .print()
    ,
    newText("score2", "2) I have never been involved in delinquent gang activity.")
        .center()
        .print()
    ,
    newText("blank9", "<p> </p>")
        .print()
    ,
    newScale("score2", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank10", "<p> </p>")
        .print()
    ,
    newText("score3", "3) Most people are wimps.")
        .center()
        .print()
    ,
    newText("blank11", "<p> </p>")
        .print()
    ,
    newScale("score3", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank12", "<p> </p>")
        .print()
    ,
    newText("score4", "4) I’ve often done something dangerous just for the thrill of it.")
        .center()
        .print()
    ,
    newText("blank13", "<p> </p>")
        .print()
    ,
    newScale("score4", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank14", "<p> </p>")
        .print()
    ,
    newText("score5", "5) I have tricked someone into giving me money.")
        .center()
        .print()
    ,
    newText("blank15", "<p> </p>")
        .print()
    ,
    newScale("score5", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank16", "<p> </p>")
        .print()
    ,
    newButton("continue01", "CONTINUE")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score6", "6) I have assaulted a law enforcement official or social worker.")
        .center()
        .print()
    ,
    newText("blank17", "<p> </p>")
        .print()
    ,
    newScale("score6", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank18", "<p> </p>")
        .print()
    ,
    newText("score7", "7) I have pretended to be someone else in order to get something.")
        .center()
        .print()
    ,
    newText("blank19", "<p> </p>")
        .print()
    ,
    newScale("score7", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank20", "<p> </p>")
        .print()
    ,
    newText("score8", "8) I like to see fist-fights.")
        .center()
        .print()
    ,
    newText("blank21", "<p> </p>")
        .print()
    ,
    newScale("score8", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank22", "<p> </p>")
        .print()
    ,
    newText("score9", "9) I would get a kick out of 'scamming' someone.")
        .center()
        .print()
    ,
    newText("blank23", "<p> </p>")
        .print()
    ,
    newScale("score9", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank24", "<p> </p>")
        .print()
    ,
    newText("score10", "10) It's fun to see how far you can push people before they get upset.")
        .center()
        .print()
    ,
    newText("blank25", "<p> </p>")
        .print()
    ,
    newScale("score10", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank26", "<p> </p>")
        .print()
    ,
    newText("score11", "11) I enjoy doing wild things.")
        .center()
        .print()
    ,
    newText("blank27", "<p> </p>")
        .print()
    ,
    newScale("score11", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank28", "<p> </p>")
        .print()
    ,
    newText("score12", "12) I have broken into a building or vehicle in order to steal something or vandalize.")
        .center()
        .print()
    ,
    newText("blank29", "<p> </p>")
        .print()
    ,
    newScale("score12", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank30", "<p> </p>")
        .print()
    ,
    newText("score13", "13) I don’t bother to keep in touch with my family any more.")
        .center()
        .print()
    ,
    newText("blank31", "<p> </p>")
        .print()
    ,
    newScale("score13", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank32", "<p> </p>")
        .print()
    ,
    newButton("continue02", "CONTINUE")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score14", "14) I rarely follow the rules.")
        .center()
        .print()
    ,
    newText("blank33", "<p> </p>")
        .print()
    ,
    newScale("score14", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank34", "<p> </p>")
        .print()
    ,
    newText("score15", "15) You should take advantage of other people before they do it to you.")
        .center()
        .print()
    ,
    newText("blank35", "<p> </p>")
        .print()
    ,
    newScale("score15", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank36", "<p> </p>")
        .print()
    ,
    newText("score16", "16) People sometimes say that I’m cold-hearted.")
        .center()
        .print()
    ,
    newText("blank37", "<p> </p>")
        .print()
    ,
    newScale("score16", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank38", "<p> </p>")
        .print()
    ,
    newText("score17", "17) I like to have sex with people I barely know.")
        .center()
        .print()
    ,
    newText("blank39", "<p> </p>")
        .print()
    ,
    newScale("score17", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank40", "<p> </p>")
        .print()
    ,
    newText("score18", "18) I love violent sports and movies.")
        .center()
        .print()
    ,
    newText("blank41", "<p> </p>")
        .print()
    ,
    newScale("score18", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank42", "<p> </p>")
        .print()
    ,
    newText("score19", "19) Sometimes you have to pretend you like people to get something out of them.")
        .center()
        .print()
    ,
    newText("blank43", "<p> </p>")
        .print()
    ,
    newScale("score19", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank44", "<p> </p>")
        .print()
    ,
    newText("score20", "20) I was convicted of a serious crime.")
        .center()
        .print()
    ,
    newText("blank45", "<p> </p>")
        .print()
    ,
    newScale("score20", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank46", "<p> </p>")
        .print()
    ,
    newText("score21", "21) I keep getting in trouble for the same things over and over.")
        .center()
        .print()
    ,
    newText("blank47", "<p> </p>")
        .print()
    ,
    newScale("score21", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank48", "<p> </p>")
        .print()
    ,
    newButton("continue03", "CONTINUE")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score22", "22) Every now and then I carry a weapon (knife or gun) for protection.")
        .center()
        .print()
    ,
    newText("blank49", "<p> </p>")
        .print()
    ,
    newScale("score22", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank50", "<p> </p>")
        .print()
    ,
    newText("score23", "23) You can get what you want by telling people what they want to hear.")
        .center()
        .print()
    ,
    newText("blank51", "<p> </p>")
        .print()
    ,
    newScale("score23", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank52", "<p> </p>")
        .print()
    ,
    newText("score24", "24) I never feel guilty over hurting others.")
        .center()
        .print()
    ,
    newText("blank53", "<p> </p>")
        .print()
    ,
    newScale("score24", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank54", "<p> </p>")
        .print()
    ,
    newText("score25", "25) I have threatened people into giving me money, clothes, or makeup.")
        .center()
        .print()
    ,
    newText("blank55", "<p> </p>")
        .print()
    ,
    newScale("score25", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank56", "<p> </p>")
        .print()
    ,
    newText("score26", "26) A lot of people are 'suckers' and can easily be fooled.")
        .center()
        .print()
    ,
    newText("blank57", "<p> </p>")
        .print()
    ,
    newScale("score26", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank58", "<p> </p>")
        .print()
    ,
    newText("score27", "27) I admit that I often 'mouth off' without thinking.")
        .center()
        .print()
    ,
    newText("blank59", "<p> </p>")
        .print()
    ,
    newScale("score27", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank60", "<p> </p>")
        .print()
    ,
    newText("score28", "28) I sometimes dump friends that I don’t need any more.")
        .center()
        .print()
    ,
    newText("blank61", "<p> </p>")
        .print()
    ,
    newScale("score28", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank62", "<p> </p>")
        .print()
    ,
    newText("score29", "29) I purposely tried to hit someone with the vehicle I was driving.")
        .center()
        .print()
    ,
    newText("blank63", "<p> </p>")
        .print()
    ,
    newScale("score29", "Disagree Strongly", "Disagree", "Neutral", "Agree", "Agree Strongly")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("last")
    ,
    newText("blank64", "<p> </p>")
        .print()
    ,
    newButton("next", "NEXT")
        .print()
        .center()
        .wait()
    )
.log( "id" , getVar("subjID"))
//.log("SRPIsFirst", getVar("questionnaireOrder").test.is(getVar("questionnaireOrder"))  
    //? ["SRP First"] 
    //: ["MLQ Second"] 
    //)

newTrial("MLQ",
    //getVar("questionnaireOrder")
    //,
    newText("<p>Please complete the following questions about your relationship to music:</p>")
        .css("font-size", "1.5em")
        .center()
        .print()
    ,
    newText("score1", "1) How often do you listen to music?")
        .center()
        .print()
    ,
    newText("blank65", "<p> </p>")
        .print()
    ,
    newScale("score1", "Several times a day", "Once a day", "A couple times a week", "Once a week", "A couple times a month", "A couple times a year")
        .labelsPosition("right")
        .center()
        .vertical()
        .print()
        .wait()
        .log()
    ,
    newText("blank66", "<p> </p>")
        .print()
    ,
    newButton("next01", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score2", "2) How often, in your estimation, is listening to music the main activity in those situations of your life where listening to music occurs (as opposed to the background activity)?")
        .center()
        .print()
    ,
    newText("blank67", "<p> </p>")
        .print()
    ,
    newScale("score2", "Never", "Seldom", "Often", "Always")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log()
    ,
    newText("blank68", "<p> </p>")
        .print()
    ,
    newButton("next02", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score3", "3) How often, in your estimation, is listening to music a “background” activity in those situations of your life where listening to music occurs (as opposed to the main activity)?")
        .center()
        .print()
    ,
    newText("blank69", "<p> </p>")
        .print()
    ,
    newScale("score3", "Never", "Seldom", "Often", "Always")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log()
    ,
    newText("blank70", "<p> </p>")
        .print()
    ,
    newButton("next03", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score4", "4) In your opinion, what can music express? [select all that apply]")
        .center()
        .print()
    ,
    newText("blank71", "<p> </p>")
        .print()
    ,
    newTextInput("score4_input")
        .center()
        .log()
    ,
    newScale("score4", "Beauty", "Emotions", "Events and objects", "Experiences that cannot be described in words", "Musical conventions", "Personality characteristics", "Physical aspects", "Psychological tension/relaxation", "Religiosity", "Social condition", "Sound patterns", "Other (please specify below)")
        .vertical()
        .checkbox()
        .center()
        .print()
        .wait()
        .log("all")
    ,
    getTextInput("score4_input")
        .print()
        .log()
    ,
    newText("blank72", "<p> </p>")
        .print()
    ,
    newButton("next04", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score5", "5) In your opinion, how often does music (or musicians) communicate with listeners?")
        .center()
        .print()
    ,
    newText("blank73", "<p> </p>")
        .print()
    ,
    newScale("score5", "Never", "Seldom", "Often", "Always")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log()
    ,
    newText("blank74", "<p> </p>")
        .print()
    ,
    newButton("next05", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score6", "6) How often do you perceive that the music you listen to expresses emotion?")
        .center()
        .print()
    ,
    newText("blank75", "<p> </p>")
        .print()
    ,
    newScale("score6", "Never", "Seldom", "Often", "Always")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log()
    ,
    newText("blank76", "<p> </p>")
        .print()
    ,
    newButton("next06", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score7", "7) Which emotions can music express? [select all that apply]")
        .center()
        .print()
    ,
    newTextInput("score7_input")
        .center()
        .log()
    ,
    newText("blank77", "<p> </p>")
        .print()
    ,
    newScale("score7", "Admiration", "Anger", "Anxiety", "Boredom", "Calm", "Confused", "Desire", "Disappointment", "Disgust", "Expectancy", "Fear", "Guilt", "Hope", "Humiliation", "Humor", "Interest", "Jealousy", "Joy", "Loneliness", "Longing", "Love", "Nostalgia", "Pain", "Pride", "Regret", "Sadness", "Satisfaction", "Shame", "Solemnity", "Surprise", "Sympathy", "Tenderness", "Tension", "Tiredness", "Trust", "All emotions", "No emotions", "Other (please specify below)")
        .vertical()
        .checkbox()
        .center()
        .labelsPosition("right")
        .print()
        .wait()
        .log("all")
    ,
    getTextInput("score7_input")
        .print()
        .log()
    ,
    newFunction("purple", () => window.scrollTo(0,0) ).call()
    ,
    newText("blank_d", "<p> </p>")
        .print()
    ,
    newButton("next07", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score8", "8) If you perceive that the music expresses a certain emotion, do you also feel that emotion?")
        .center()
        .print()
    ,
    newText("blank_e", "<p> </p>")
        .print()
    ,
    newScale("score8", "Never", "Seldom", "Often", "Always")
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log()
    ,
    newText("blank_f", "<p> </p>")
        .print()
    ,
    newButton("next08", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score9", "9) Which emotions do you feel when listening to music? [select all that apply]")
        .center()
        .print()
    ,
    newText("blank_g", "<p> </p>")
        .print()
    ,
    newTextInput("score9_input")
        .center()
    ,
    newScale("score9", "Admiration", "Anger", "Anxiety", "Boredom", "Calm", "Confused", "Desire", "Disappointment", "Disgust", "Expectancy", "Fear", "Guilt", "Hope", "Humiliation", "Humor", "Interest", "Jealousy", "Joy", "Loneliness", "Longing", "Love", "Nostalgia", "Pain", "Pride", "Regret", "Sadness", "Satisfaction", "Shame", "Solemnity", "Surprise", "Sympathy", "Tenderness", "Tension", "Tiredness", "Trust", "All emotions", "No emotions", "Other (please specify below)")
        .vertical()
        .checkbox()
        .labelsPosition("right")
        .center()
        .print()
        .wait()
        .log("all")
    ,
    getTextInput("score9_input")
        .print()
        .log()
    ,
    // hello, Michaela, Erin here
    // just so you know, this is throwing an error 
    // because it's a repeat function declaration 
    // from earlier. If they do 
    newFunction( () => window.scrollTo(0,0) ).call()
    ,
    newText("blank_h", "<p> </p>")
        .print()
    ,
    newButton("next09", "NEXT")
        .settings.center()
        .print()
        .wait()
    ,
    clear()
    ,
    newText("score10", "10) How much of the total time spent listening to music do you feel strong emotions? [Enter a number between 0 (i.e., Never) and 100 (i.e., Always) and press return/enter.]")
        .center()
        .print()
    ,
    newText("blank_b", "<p> </p>")
        .print()
    ,
    newTextInput("score10_input")
        .center()
        .log()
        .print()
        .wait()
    ,
    newText("error_1", "Please enter a number between 0 and 100.")
        .center()
        .color("red")
        .print()
        .hidden()
    ,
    newText("blank_a", "<p> </p>")
        .print()
    ,
    newButton("continue_16", "CONTINUE")
        .center()
        .print()
        .callback(
            getTextInput("score10_input").test.text( /^\d+$/ )
            .success(getText("error_1").settings.hidden())
            .failure(getText("error_1").settings.visible())
        )
    .wait(getTextInput("score10_input").test.text(( /^\d+$/ )))
    )
.log("id", getVar("subjID"))
//.log("MLQIsFirst", getVar("questionnaireOrder").test.is(getVar("questionnaireOrder"))  
    //? ["MLQ First"] 
    //: ["SRP Second"] 
    //)


